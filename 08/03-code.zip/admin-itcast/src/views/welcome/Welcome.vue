<template>
  <div>欢迎登录</div>
</template>
<script>
export default {

}
</script>
<style lang="scss" scoped>

</style>
